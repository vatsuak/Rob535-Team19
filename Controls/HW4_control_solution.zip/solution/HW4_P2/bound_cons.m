function [ Lb, Ub ] = bound_cons(initial_idx,U_ref,npred,input_range,nstates,ninputs)
%time_idx is the index along uref the initial condition is at
xsize = (npred+1)*nstates ;
usize = npred*ninputs ;

Lb = [] ;
Ub = [] ;
for j = 1:ninputs
Lb = [Lb;input_range(j,1)-U_ref(j,initial_idx:initial_idx+npred-1)] ;
Ub = [Ub;input_range(j,2)-U_ref(j,initial_idx:initial_idx+npred-1)] ;
end

Lb = reshape(Lb,[usize,1]) ;
Ub = reshape(Ub,[usize,1]) ;

Lb = [-Inf(xsize,1); Lb] ;
Ub = [Inf(xsize,1); Ub] ;

end